package cn.zwz.test.service;

import com.baomidou.mybatisplus.extension.service.IService;
import cn.zwz.test.entity.Student;

/**
 * 学生 服务层接口
 * @author 郑为中
 */
public interface IStudentService extends IService<Student> {

}