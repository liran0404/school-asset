package cn.zwz.data.service;

import cn.zwz.data.entity.Setting;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * 设置 服务层接口
 * @author 郑为中
 */
public interface ISettingService extends IService<Setting> {

}
