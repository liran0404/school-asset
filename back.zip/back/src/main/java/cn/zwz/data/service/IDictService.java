package cn.zwz.data.service;

import cn.zwz.data.entity.Dict;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * 数据字典 服务层接口
 * @author 郑为中
 */
public interface IDictService extends IService<Dict> {

}
