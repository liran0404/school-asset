package cn.zwz.data.service;

import cn.zwz.data.entity.Log;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * 系统日志 服务层接口
 * @author 郑为中
 */
public interface ILogService extends IService<Log> {

}
