package cn.zwz.assets.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import cn.zwz.assets.entity.AdminAsset;

/**
 * 行政资产类型数据处理层
 * @author 开发者
 */
public interface AdminAssetMapper extends BaseMapper<AdminAsset> {
}