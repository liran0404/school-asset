package cn.zwz.assets.service;

import com.baomidou.mybatisplus.extension.service.IService;
import cn.zwz.assets.entity.AdminAssetsRepair;

/**
 * 固定资产报修 服务层接口
 * @author 开发者
 */
public interface IAdminAssetsRepairService extends IService<AdminAssetsRepair> {

}