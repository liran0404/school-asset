package cn.zwz.assets.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import cn.zwz.assets.entity.AdminAssetUnit;

/**
 * 行政资产计量单位数据处理层
 * @author 开发者
 */
public interface AdminAssetUnitMapper extends BaseMapper<AdminAssetUnit> {
}