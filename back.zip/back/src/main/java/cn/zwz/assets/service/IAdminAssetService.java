package cn.zwz.assets.service;

import cn.zwz.assets.entity.AdminAsset;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;
import java.util.Map;
/**
 * 行政资产类型接口
 * @author 开发者
 */
public interface IAdminAssetService extends IService<AdminAsset> {
    // 新增方法，统计不同资产名称的数量
    List<Map<String, Object>> countAssetsByName();
}