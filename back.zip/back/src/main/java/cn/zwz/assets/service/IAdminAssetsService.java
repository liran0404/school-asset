package cn.zwz.assets.service;

import cn.zwz.assets.entity.AdminAssets;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * 行政资产库存接口
 * @author 开发者
 */
public interface IAdminAssetsService extends IService<AdminAssets> {
}