package cn.zwz.assets.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import cn.zwz.assets.entity.AdminAssetWare;

/**
 * 行政资产仓库档案数据处理层
 * @author 开发者
 */
public interface AdminAssetWareMapper extends BaseMapper<AdminAssetWare> {

}