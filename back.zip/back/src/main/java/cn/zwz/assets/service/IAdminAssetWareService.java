package cn.zwz.assets.service;

import cn.zwz.assets.entity.AdminAssetWare;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * 行政资产仓库档案接口
 * @author 开发者
 */
public interface IAdminAssetWareService extends IService<AdminAssetWare> {

}