package cn.zwz.assets.service;

import cn.zwz.assets.entity.AdminAssetSupplier;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * 行政资产供应商接口
 * @author 开发者
 */
public interface IAdminAssetSupplierService extends IService<AdminAssetSupplier> {

}