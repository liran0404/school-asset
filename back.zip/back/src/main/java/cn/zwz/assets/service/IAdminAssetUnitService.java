package cn.zwz.assets.service;

import cn.zwz.assets.entity.AdminAssetUnit;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * 行政资产计量单位接口
 * @author 开发者
 */
public interface IAdminAssetUnitService extends IService<AdminAssetUnit> {
}