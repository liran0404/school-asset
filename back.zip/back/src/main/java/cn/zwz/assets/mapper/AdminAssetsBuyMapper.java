package cn.zwz.assets.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import cn.zwz.assets.entity.AdminAssetsBuy;

/**
 * 行政资产采购数据处理层
 * @author 开发者
 */
public interface AdminAssetsBuyMapper extends BaseMapper<AdminAssetsBuy> {
}